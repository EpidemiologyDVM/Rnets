#Rnets v 0.9.5

## Major Changes

* 0.9.5 
    + Added news.md
    + Added README.md
    + check() produces 2 'notes'
  
* 0.9.6
    + Initial 'open beta' relase
    + Changed 'Modularity_Signed' to 'signedModularity'
    + Revised signedModularity
    + Changed S4 naming convention from 'rnet.basic' to 'rnetBasic'
    + `check()` produces 0 errors/warnings/notes (other than UTF-8 warning)
