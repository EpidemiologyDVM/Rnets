#Rnets v 0.9.5

## Major Changes

* 0.9.5 
    + Initial 'open beta' relase
    + Added news.md
    + Added README.md
    + check() produces 2 'notes'
  

