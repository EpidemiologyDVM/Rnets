ABX_LIST <- c(
  'AMP',
  'AMC',
  'AXO',
  'FOX',
  'TIO',
  'STR',
  'GEN',
  'KAN',
  'NAL',
  'CIP',
  'FIS',
  'COT',
  'AZI',
  'CHL',
  'TET'
)

EC08_Rnet <- Rnet(
  NARMS_EC_DATA,
  L1 = 0.25,
  Stratify = NARMS_EC_DATA$Year == 2008,
  V_set = ABX_LIST
  )

EC08_edgeFrame1 <- as.data.frame(as_edgelist(EC08_Rnet@R)))
EC08_edgeFrame <- Sq2L(EC08_Rnet@Omega, keep = c(T, F, F))
signedModularity(EC08_edgeFrame)