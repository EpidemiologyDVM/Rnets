## ---- echo = FALSE, results = 'hide', message = F------------------------
library(Rnets)
#load(file = 'data\\NARMS_EC_DATA.rda')


## ------------------------------------------------------------------------

#Define the set of antimicrobials to include in the Rnet
ABX_LIST <- c('AMC', 'AXO', 'TIO', 'CIP', 'TET', 'STR', 'GEN', 'CHL')

#Estimate the Rnet
EC_all_Rnet <- Rnets::Rnet(x = NARMS_EC_DATA, L1 =  0.25, vert = ABX_LIST)
                
#View Results
summary(EC_all_Rnet)

## ------------------------------------------------------------------------
EC_all_L1Selection <- L1Selection(
            x = NARMS_EC_DATA, 
            L1_values = seq(0.05, 0.50, 0.05),
            n_b = 1500,
            vert = ABX_LIST
            )

print(EC_all_L1Selection@D, 4)

