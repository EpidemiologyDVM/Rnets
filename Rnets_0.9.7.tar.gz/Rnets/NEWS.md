#Rnets v 0.9.5

## Major Changes

* 0.9.5 
    + Added news.md
    + Added README.md
    + check() produces 2 'notes'
  
* 0.9.6
    + Changed 'Modularity_Signed' to 'signedModularity'
    + Revised signedModularity
    + Changed S4 naming convention from 'rnet.basic' to 'rnetBasic'
    + `check()` produces 0 errors/warnings/notes (other than UTF-8 warning)

* 0.9.7
    + Initial 'open beta' relase
    + Removed signedModularity.data.frame 
    + Revised signedModularity to matrix-based algorithm instead of list-based
    